package group.yrmjhtdjxh.punch.VO;

import lombok.Data;

import java.util.Date;

@Data
public class TimeRecordVO {

    private Float totalHourOfOneDay;

    private Date date;
}
