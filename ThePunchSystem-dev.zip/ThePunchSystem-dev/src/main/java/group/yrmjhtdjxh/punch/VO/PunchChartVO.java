package group.yrmjhtdjxh.punch.VO;

import lombok.Data;

import java.util.List;

/**
 * @author dengg
 */
@Data
public class PunchChartVO {

    private List<TimeRecordVO> list;

}
