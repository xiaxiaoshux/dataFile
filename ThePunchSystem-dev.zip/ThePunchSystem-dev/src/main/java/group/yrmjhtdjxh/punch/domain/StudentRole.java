package group.yrmjhtdjxh.punch.domain;

import lombok.Data;

/**
 * @author dengg
 */
@Data
public class StudentRole {

    private Long userId;

    private Integer userRole;

}
